/*
var li_items = document.querySelectorAll(".sidebar ul li");
var hamburger = document.querySelector(".hamburger");
var wrapper = document.querySelector(".wrapper");
li_items.forEach((li_item)=>{
   li_item.addEventListener("mouseenter", ()=>{

    li_item.closest(".wrapper").classList.remove("hover_collapse");

  })
})
li_items.forEach((li_item)=>{
   li_item.addEventListener("mouseleave", ()=>{

    li_item.closest(".wrapper").classList.add("hover_collapse");

   })
})
hamburger.addEventListener("click", () => {

    hamburger.closest(".wrapper").classList.toggle("hover_collapse");
})

function toggleSidebar() {
    document.querySelector('.wrapper').classList.toggle('hover_collapse');
}

*/
//Function to handle sidebar mouseenter and mouseleave events
function handleSidebarHover() {
    const liItems = document.querySelectorAll('.sidebar ul li');
    const wrapper = document.querySelector('.wrapper');

    liItems.forEach((liItem) => {
        liItem.addEventListener('mouseenter', () => {
            wrapper.classList.remove('hover_collapse');
        });
    });

    liItems.forEach((liItem) => {
        liItem.addEventListener('mouseleave', () => {
            wrapper.classList.add('hover_collapse');
        });
    });
}

// Function to handle hamburger click event
function handleHamburgerClick() {
    const hamburger = document.querySelector('.hamburger');
    const wrapper = document.querySelector('.wrapper');

    hamburger.addEventListener('click', () => {
        wrapper.classList.toggle('hover_collapse');
    });
}
function init() {
    // Ensure all sidebar links navigate correctly
    document.querySelectorAll('.sidebar ul li a').forEach(link => {
        link.addEventListener('click', function(event) {
            const targetHref = event.currentTarget.getAttribute('href');
            if (targetHref) {
                window.location.href = targetHref;
            }
        });
    });

    handleSidebarHover();
    handleHamburgerClick();
}

document.addEventListener('DOMContentLoaded', init);