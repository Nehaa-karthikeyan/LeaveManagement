document.addEventListener('DOMContentLoaded', (event) => {
    selectFilter('none');
    fetchReportData();
    init();
});

function fetchReportData() {
    const reportData = [
        { userId: 'EMP00001', name: 'Henry', work: 'WFO', Project:'DOXZON',Task: 'Testing',date: '24/07/2024', startTime: '03:38', endTime: '04:38', timeSpent: '1h 0m', status: 'Yes', comments: 'Yes' },
        { userId: 'EMP00002', name: 'Joe', work: 'WFO',  Project:'FINCORT', Task: 'Design', date: '25/07/2024', startTime: '03:38', endTime: '04:38', timeSpent: '1h 0m', status: 'Yes', comments: 'Yes' },
        { userId: 'EMP00003', name: 'Roosie', work: 'WFH', Project:'MEDITECH', Task: 'Dashboard', date: '25/07/2024',startTime: '03:38', endTime: '04:38', timeSpent: '1h 0m', status: 'Yes', comments: 'Yes' }
    ];
    displayReportData(reportData);
}

function toggleSidebar() {
    const wrapper = document.querySelector('.wrapper');
    wrapper.classList.toggle('hover_collapse');
    wrapper.classList.toggle('sidebar_collapsed');
}

function displayReportData(data) {
    const tableBody = document.querySelector('#reportTable tbody');
    tableBody.innerHTML = '';
    data.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.userId}</td>
            <td>${item.name}</td>
            <td>${item.work}</td>
            <td>${item.Project}</td>
            <td>${item.Task}</td>
            <td>${item.date}</td>
            <td>${item.startTime}</td>
            <td>${item.endTime}</td>
            <td>${item.timeSpent}</td>
            <td>${item.status}</td>
            <td>${item.comments}</td>
        `;
        tableBody.appendChild(row);
    });
}

function selectFilter(filterType) {
    document.querySelectorAll('.filterInput').forEach(input => {
        input.style.display = 'none';
    });
    if (filterType != 'none') {
        document.getElementById(`${filterType}Filter`).style.display = 'inline-block';
    }
    

    // Update the dropdown button text
    const dropdownButton = document.querySelector('.dropbtn');
    dropdownButton.textContent = filterType.charAt(0).toUpperCase() + filterType.slice(1);
}



document.addEventListener('DOMContentLoaded', function() {
    var applyButton = document.getElementById('applyFiltersButton');
    if (applyButton) {
        applyButton.addEventListener('click', applyFilters);
    } else {
        console.error('Apply Filters button not found.');
    }
});



function applyFilters() {
    var filterTypeButton = document.querySelector('.dropbtn');
    var filterType = filterTypeButton.textContent.trim().toLowerCase();

    //filterType = filterType.charAt(0).toUpperCase() + filterType.slice(1);

   
    var filterIdMap = {
        'userid': 'userIdInput',
        'project': 'projectInput'
    };
    

    var filterInputId = filterIdMap[filterType];
    if (filterType === 'none') {
        displayAllRows();
        return;
    }

    var filterValueInput = document.getElementById(filterInputId);

    if (filterValueInput) {
        var filterValue = filterValueInput.value.trim().toLowerCase();

        var table = document.getElementById('reportTable');
        var rows = table.getElementsByTagName('tr');

        for (var i = 1; i < rows.length; i++) {
            var cells = rows[i].getElementsByTagName('td');
            if (cells.length > 0) {
                var textValue;
                if (filterType === 'userid') {
                    textValue = cells[0].textContent.toLowerCase();
                } else if (filterType === 'project') {
                    textValue = cells[3].textContent.toLowerCase();
                }
                if (textValue && textValue.includes(filterValue)) {
                    rows[i].style.display = '';
                } else {
                    rows[i].style.display = 'none';
                }
            }
        }
    } else {
        console.error('Filter value input not found.');
    }
}

function displayAllRows() {
    var table = document.getElementById('reportTable');
    var rows = table.getElementsByTagName('tr');
    for (var i = 1; i < rows.length; i++) { 
        rows[i].style.display = '';
    }
}

function handleSidebarHover() {
    const liItems = document.querySelectorAll('.sidebar ul li');
    const wrapper = document.querySelector('.wrapper');

    liItems.forEach((liItem) => {
        liItem.addEventListener('mouseenter', () => {
            wrapper.classList.remove('hover_collapse');
        });
    });

    liItems.forEach((liItem) => {
        liItem.addEventListener('mouseleave', () => {
            wrapper.classList.add('hover_collapse');
        });
    });
}


function handleHamburgerClick() {
    const hamburger = document.querySelector('.hamburger');
    const wrapper = document.querySelector('.wrapper');

    hamburger.addEventListener('click', () => {
        wrapper.classList.toggle('hover_collapse');
    });
}

function init() {
    document.querySelectorAll('.sidebar ul li a').forEach(link => {
        link.addEventListener('click', function(event) {
            const targetHref = event.currentTarget.getAttribute('href');
            if (targetHref) {
                window.location.href = targetHref;
            }
        });
    });

    handleSidebarHover();
    handleHamburgerClick();

    var applyButton = document.getElementById('applyFiltersButton');

    if (applyButton) {
        applyButton.addEventListener('click', applyFilters);
    } else {
        console.error('Apply Filters button not found.');
    }
}