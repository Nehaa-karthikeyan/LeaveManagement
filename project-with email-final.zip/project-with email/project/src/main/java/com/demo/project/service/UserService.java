package com.demo.project.service;

import java.util.List;

import com.demo.project.entity.User;
import com.demo.project.entity.UserReg;

public interface UserService {
	List<User> getAllUsers();
    String findByEmpid(String empid);
    List<User> getAllTasks() ;
    public void registerUser(User user);
    User saveUserDetails(User user, String empid);
    //void sendVerificationCode(UserReg userReg, String code);
}
	