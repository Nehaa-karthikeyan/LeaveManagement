package com.demo.project.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.project.entity.User;
import com.demo.project.entity.UserReg;



public interface UserRepository extends JpaRepository<UserReg, Long> {
    UserReg findByEmpid(String username);
    UserReg findByEmail(String email);
    long count();
    @Query("SELECT u FROM User u WHERE u.userReg.empid = :empid")
    List<User> findByUserRegEmpid(@Param("empid") String empid);
	
}
