package com.demo.project.service;

public class UserAlreadyRegisteredException  extends RuntimeException  {
	public UserAlreadyRegisteredException(String message) {
        super(message);
    }
}
