package com.demo.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.demo.project.entity.LeaveApplication;
import com.demo.project.service.LeaveApplicationService;

@Controller
public class LeaveController {
    @Autowired
    private LeaveApplicationService leaveApplicationService;

    @GetMapping("/leave")
    public String showLeaveForm(Model model) {
        model.addAttribute("leaveApplication", new LeaveApplication());
        return "leave";
    }

    @PostMapping("/applyLeave")
    public String applyLeave(@ModelAttribute LeaveApplication leaveApplication) {
        // Process the leave application
        //System.out.println(leaveApplication);
    	leaveApplicationService.saveLeaveApplication(leaveApplication);
        return "redirect:/leave";
    }
    
}