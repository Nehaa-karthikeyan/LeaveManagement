package com.demo.project.controller;

//import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.demo.project.entity.User;
import com.demo.project.entity.UserReg;
import com.demo.project.service.UService;
import com.demo.project.service.UserAlreadyRegisteredException;
import com.demo.project.service.UserService;

//import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	
	@Autowired
	private UserService service;
	
	@Autowired
	private UService userservice;
	
	public UserController(UService userService) {
        this.userservice = userService;
    }
	
	
	@GetMapping("/")
	public String registerU(Model model) {
		UserReg user=new UserReg();
		model.addAttribute("user",user);
		return "index"; 
	}
	@GetMapping("/register")
	public String register(Model model) {
		User user=new User();
		model.addAttribute("user",user);
		return "register"; 
	}
	@GetMapping("/login")
	public String registerlog(Model model) {
		UserReg user=new UserReg();
		model.addAttribute("user",user);
		return "login"; 
	}
	
	/*@PostMapping("/registerUser")
	public String registerUser(@ModelAttribute("user") User user) {
		System.out.println(user);
		service.registerUser(user);
		return "home";
	}*/
	 /* @GetMapping("/taskList")
	    public String showTaskList(Model model) {
	        List<User> tasks = service.getAllTasks();
	        model.addAttribute("tasks", tasks);
	        return "taskList"; // Make sure this returns the template for the task list
	    }
	    */
	// GetMapping for displaying settings page
    @GetMapping("/settings")
    public String showSettingsPage(HttpSession session, Model model) {
        String empid = (String) session.getAttribute("empid");
        if (empid == null) {
            return "redirect:/login"; // Redirect to login if session is invalid
        }

        // Retrieve user details by empid
        UserReg user = userservice.getUserDetailsByEmpid(empid);
        model.addAttribute("user", user);
        return "settings"; // Assuming settings.html or similar exists in templates directory
    }
    
    // PostMapping for updating user settings
    @PostMapping("/settings/update")
    public String updateSettings(HttpSession session, @ModelAttribute UserReg updatedUser) {
        String empid = (String) session.getAttribute("empid");
        if (empid == null) {
            return "redirect:/login"; // Redirect to login if session is invalid
        }

        // Update user details using userService or uService
        userservice.updateUserDetails(updatedUser);

        // Redirect to settings page or any other page after update
        return "redirect:/settings";
    }
	
	@PostMapping("/registerUser")
	public String registerUser(HttpSession session, @ModelAttribute("user") User user, @RequestParam("empid") String empid) {
	    // Retrieve the empid from session if not passed
	    if (empid == null || empid.isEmpty()) {
	        empid = (String) session.getAttribute("empid");
	    }

	    // Set the empid to the User entity
	    UserReg userReg = userservice.getUserByEmpid(empid);
	    if (userReg != null) {
	        user.setUserReg(userReg);
	        service.registerUser(user);
	        System.out.println("Success");
	        return "home"; // Redirect to a success page or any other page
	    }

	    return "home"; // Redirect to an error page if userReg is not found
	}

	@GetMapping("/taskList")
	public String getTaskList(HttpSession session, Model model) {
	    String empid = (String) session.getAttribute("empid");
	    if (empid == null) {
	        return "redirect:/login"; // Redirect to login if session is invalid
	    }

	    List<User> tasks = userservice.getTasksByEmpid(empid);
	    model.addAttribute("tasks", tasks);
	    return "taskList";
	}
	  @GetMapping("/tasks")
	    public String getTasks(Model model) {
	       // List<User> tasks = service.getAllUsers();
	        List<User> tasks = service.getAllTasks();
	        for (User task : tasks) {
	            System.out.println("Task: " + task + ", UserReg: " + task.getUserReg());
	        }// Adjust according to your actual service method
	        model.addAttribute("tasks", tasks);
	        return "taskList"; 
	  }
	  @GetMapping("/api/tasks")
	  @ResponseBody
	  public ResponseEntity<List<User>> getTasksByEmpid(@RequestParam String empid) {
	      List<User> tasks = userservice.getTasksByEmpid(empid);
	      return ResponseEntity.ok(tasks);
	  }

	  @GetMapping("/resetpwd")
	    public String resetPassword() {
	        return "resetpwd"; 
	    }
	  
	 
	   /* @PostMapping("/register")
	    public User registerUser(@RequestBody User user) {
	        return userService.registerUser(user);
	    }*/
	    @PostMapping("/api/register")
	    public ResponseEntity<?> registerUser(@RequestBody UserReg user) {
	        try {
	        	UserReg registeredUser = userservice.registerUser(user);
	            return new ResponseEntity<>(registeredUser, HttpStatus.CREATED);
	        } catch (UserAlreadyRegisteredException e) {
	            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
	        }
	    }
	  
	/*  @PostMapping("/api/register")
	    public ResponseEntity<?> registerUser(@RequestBody UserReg user) {
	        try {
	            UserReg registeredUser = userservice.registerUser(user);
	            String verificationCode = userservice.generateVerificationCode();
	            service.sendVerificationCode(registeredUser, verificationCode);
	            return ResponseEntity.status(HttpStatus.CREATED).body("Verification code sent to email.");
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
	        }
	    }*/
	    
	    @PostMapping("/api/login")
	    public ResponseEntity<?> login(HttpSession session,@RequestBody Map<String, String> payload) {
	        String empid = payload.get("empid");
	        String password = payload.get("password");

	        if (empid == null || password == null) {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Missing empid or password");
	        }

	        boolean isAuthenticated = userservice.authenticateUser(empid, password);
	        if (isAuthenticated) {
	        	 UserReg userReg = userservice.getUserByEmpid(empid);
	        	// if (userReg != null) {
	        		// User user=new User();
	        		//service.saveUserDetails(user, empid);
	                 // Store empid and username in session
	                 session.setAttribute("empid", empid);
	                 session.setAttribute("username", userReg.getUsername());
	                 // Return user details
	                 return ResponseEntity.ok(userReg);
	        	 
	        	/* else {
	                 return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found");
	             }*/
	           // return ResponseEntity.ok("Login successful");
	        } else {
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Incorrect Password");
	        }
	       
	    }
	    
	    @GetMapping("/api/session")
	    public ResponseEntity<?> getSessionDetails(HttpSession session) {
	        String username = (String) session.getAttribute("username");
	        String empid = (String) session.getAttribute("empid");
	        if (username != null && empid != null) {
	            return ResponseEntity.ok(Map.of("username", username, "empid", empid));
	        } else {
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
	        }
	    }
	    
	    @GetMapping("/verifyCode")
	    public String showVerifyCodePage() {
	        return "verifyCode"; // Assuming verifyCode.html is in templates directory
	    }

	   /* @PostMapping("/api/login")
	    public ResponseEntity<?> loginUser(@RequestBody UserReg user) {
	        UserReg loggedInUser = userservice.loginUser(user.getEmpid(), user.getPassword());
	        if (loggedInUser != null) {
	            return new ResponseEntity<>(loggedInUser, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>("Invalid credentials", HttpStatus.UNAUTHORIZED);
	        }
	    }*/
	    /*public UserReg loginUser(@RequestBody UserReg user) {
	        return userservice.loginUser(user.getEmpid(), user.getPassword());
	    }*/
	    @PostMapping("/api/forgot-password")
	    public ResponseEntity<String> forgotPassword(@RequestBody UserReg user) {
	        boolean isReset = userservice.resetPassword(user.getEmpid(), user.getPassword());
	        if (isReset) {
	            return ResponseEntity.ok("Password reset successfully.");
	        } else {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to reset password.");
	        }
	    }
	    /*public String forgotPassword(@RequestBody UserReg user) {
	        boolean isReset = userservice.resetPassword(user.getEmpid(), user.getPassword());
	        if (isReset) {
	            return "Password reset successfully.";
	        } else {
	            return "Failed to reset password.";
	        }
	      
	        
	        
	    }
	   /* @PostMapping("/send-verification-code")
	    public ResponseEntity<String> sendVerificationCode(@RequestBody VerificationRequest request) {
	        // Implement logic to send verification code via email
	        // You can use a service class to handle the email sending
	        // For simplicity, I'll show a basic implementation
	        String email = request.getEmail();
	        boolean emailSent = sendEmail(email); // Replace with your email sending logic
	       // userservice.sendVerificationCodeByEmail(email,)
	        if (emailSent) {
	            return ResponseEntity.ok().body("Verification code sent successfully");
	        } else {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send verification code");
	        }
	    }
	    
	    private boolean sendEmail(String email) {
	        // Implement your email sending logic here
	        // You can use libraries like JavaMailSender to send emails
	        System.out.println("Sending verification code to: " + email);
	        // Example logic: return true if email sent successfully, false otherwise
	        return true; // Replace with actual logic
	    }*/
	    @PostMapping("/send-verification-code")
	    public ResponseEntity<String> sendVerificationCode(@RequestBody VerificationRequest request) {
	        try {
	            String email = request.getEmail();
	            userservice.sendVerificationCode(email);
	            return ResponseEntity.ok().body("Verification code sent successfully");
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send verification code");
	        }
	    }
	    @GetMapping("/ForgotPassword")
	    public String showForgotPasswordForm() {
	        // Logic to display forgot password form
	        return "ForgotPassword"; // Return the name of the HTML template (assuming Thymeleaf or similar)
	    }
	    
	    @PostMapping("/save-user")
	    public ResponseEntity<?> saveUser(@RequestBody User user, @RequestParam String empid) {
	        try {
	            User savedUser = userservice.saveUserDetails(user, empid);
	            return ResponseEntity.ok(savedUser);
	        } catch (RuntimeException e) {
	            return ResponseEntity.badRequest().body(e.getMessage());
	        }
	    }
	
	   /* @PostMapping("/verify-code")
	    @ResponseBody
	    public ResponseEntity<String> verifyCode(@RequestBody VerificationRequest request) {
	        System.out.println("Received request to verify code for email: " + request.getEmail()+"Code:"+request.getVerificationCode());

	        boolean isVerified = userservice.verifyVerificationCode(request.getEmail(), request.getVerificationCode());
	        if (isVerified) {
	            return ResponseEntity.ok("Verification successful.");
	        } else {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid verification code.");
	        }
	    }*/
	    
	   /* @PostMapping("/verify-code")
	    @ResponseBody
	    public ResponseEntity<String> verifyCode(@RequestBody VerificationRequest request) {
	        String email = request.getEmail();
	        String verificationCode = request.getVerificationCode();

	        // Fetch the user based on the email
	        UserReg user = userservice.findByEmail(email);

	        // Check if user exists
	        if (user == null) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found for email: " + email);
	        }

	        // Verify the verification code
	        boolean isVerified = userservice.verifyVerificationCode(email, verificationCode);
	        if (isVerified) {
	            return ResponseEntity.ok("Verification successful.");
	        } else {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid verification code.");
	        }
	    }*/
	    
	    /*@PostMapping("/verify-code")
	    @ResponseBody
	    public ResponseEntity<Map<String, Object>> verifyCode(@RequestBody VerificationRequest request) {
	        String email = request.getEmail();
	        String verificationCode = request.getVerificationCode();

	        Map<String, Object> response = new HashMap<>();
	        
	        // Fetch the user based on the email
	        UserReg user = userservice.findByEmail(email);

	        if (user == null) {
	            response.put("success", false);
	            response.put("message", "User not found for email: " + email);
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	        }

	        // Verify the verification code
	        boolean isVerified = userservice.verifyVerificationCode(email, verificationCode);
	        if (isVerified) {
	            response.put("success", true);
	            response.put("message", "Verification successful.");
	            return ResponseEntity.ok(response);
	        } else {
	            response.put("success", false);
	            response.put("message", "Invalid verification code.");
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	        }
	    }*/
	    @PostMapping("/verify-code")
	    @ResponseBody
	    public ResponseEntity<Map<String, Object>> verifyCode(@RequestBody VerificationRequest request) {
	        String email = request.getEmail();
	        String verificationCode = request.getVerificationCode();

	        Map<String, Object> response = new HashMap<>();
	        
	        // Fetch the user based on the email
	        UserReg user = userservice.findByEmail(email);

	        if (user == null) {
	            response.put("success", false);
	            response.put("message", "User not found for email: " + email);
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	        }

	        // Verify the verification code
	        boolean isVerified = userservice.verifyVerificationCode(email, verificationCode);
	        if (isVerified) {
	            response.put("success", true);
	            response.put("message", "Verification successful.");
	            response.put("empid", user.getEmpid()); // Include empid in the response
	            return ResponseEntity.ok(response);
	        } else {
	            response.put("success", false);
	            response.put("message", "Invalid verification code.");
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	        }
	    }


	    @PostMapping("/create")
        public User createUser(@RequestBody User user, @RequestParam String empid) {
            return userservice.createUser(user, empid);
        }
	
	   public static class VerificationRequest {
	    	private String email;
	        private String verificationCode;
	        public String getEmail() {
				return email;
			}
			public void setEmail(String email) {
				this.email = email;
			}
			public String getVerificationCode() {
				return verificationCode;
			}
			public void setVerificationCode(String verificationCode) {
				this.verificationCode = verificationCode;
			}
			}

	       


@GetMapping("/api/loggedInEmployee")
public ResponseEntity<Map<String, String>> getLoggedInEmployee(HttpSession session) {
    String empid = (String) session.getAttribute("empid");
    String username = (String) session.getAttribute("username");

    if (empid != null && username != null) {
        Map<String, String> employee = new HashMap<>();
        employee.put("id", empid);
        employee.put("username", username);
        return ResponseEntity.ok(employee);
    } else {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
    }
}
}
