package com.demo.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.project.entity.User;
import com.demo.project.entity.UserReg;

public interface UserRepo extends JpaRepository<User,Long>{
	 @Query("SELECT u FROM User u WHERE u.userReg.empid = :empid")
	 UserReg findByEmpid(@Param("empid")String empid);
	// UserReg findByEmpid(String empid);
}
