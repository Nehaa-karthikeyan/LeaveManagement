package com.demo.project.service;

import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.project.entity.User;
import com.demo.project.entity.UserReg;
import com.demo.project.repo.UserRepo;

import jakarta.transaction.Transactional;
@Service
public class UserServiceImpl implements UserService{
    @Autowired
	private UserRepo repo;
    //private UserRepository ur;
    @Autowired
    private EmailService emailService;
	@Override
	public void registerUser(User user) {
		// TODO Auto-generated method stub
		repo.save(user);
		
	}
	  @Override
	   public List<User> getAllTasks() {
	        return repo.findAll();
	    }
	  
	  @Override
	    public List<User> getAllUsers() {
	        return repo.findAll();
	    }
	  @Override
	    public String findByEmpid(String empid) {
	        UserReg userReg = repo.findByEmpid(empid);
	        if (userReg != null) {
	            return userReg.getUsername();
	        }
	        return null;
	    }
	  private static final Logger logger = LoggerFactory.getLogger(UserService.class);
	  @Override
	    public User saveUserDetails(User user, String empid) {
	        logger.info("Saving user details for empid: {}", empid);

	        UserReg userReg = repo.findByEmpid(empid);
	        System.out.println(userReg);
	        if (userReg != null) {
	            user.setUserReg(userReg);
	            System.out.println("Success");
	            return repo.save(user);
	        }
	        return null;
	    }
	  
	 /* @Override
	    public void sendVerificationCode(UserReg userReg, String code) {
	        String subject = "Your Verification Code";
	        String message = "Your verification code is: " + code;

	        emailService.sendSimpleEmail(userReg.getEmail(), subject, message);
	    }

	    public String generateVerificationCode() {
	        Random random = new Random();
	        int code = 100000 + random.nextInt(900000); // Generates a 6-digit code
	        return String.valueOf(code);
	    }*/

}
