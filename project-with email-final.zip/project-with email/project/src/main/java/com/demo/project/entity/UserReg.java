package com.demo.project.entity;



import java.util.List;
import java.util.Random;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;




@Entity
@Table(name = "user1")
public class UserReg {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username")
    private String username;

    @Column(name = "password")
    private String password;
    @Column(name = "email")
    private String email;
    @Column(name = "mobile")
    private String mobile;
    
    @Column(name="empid",unique=true)
    private String empid;
    

    public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public UserReg() {
        // Default constructor
    }

	


	public UserReg(String username, String password, String email, String mobile, String empid) {
		super();
		this.username = username;
		this.password = password;
		this.email = email;
		this.mobile = mobile;
		this.empid = empid;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    @OneToMany(mappedBy = "userReg")
    private List<User> users;
    @Override
    public String toString() {
        return "User [id=" + id + ", username=" + username + ", password=" + password + "]";
    }
    private String verificationCode;
    public String getVerificationCode() {
        return verificationCode;
    }

	public void setVerificationCode(String verificationCode) {
		this.verificationCode=verificationCode;
		
	}

	public String generateVerificationCode() {
		Random random = new Random();
        int code = 100000 + random.nextInt(900000); 
        System.out.println(code);// Generate a 6-digit code
        return String.valueOf(code);
	}
	 public boolean verifyVerificationCode(String codeToVerify) {
	        return this.verificationCode != null && this.verificationCode.equals(codeToVerify);
	    }
}