package com.demo.project.service;
import java.util.List;
import java.util.Random;
import com.demo.project.controller.UserController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.demo.project.entity.User;
import com.demo.project.entity.UserReg;
import com.demo.project.repo.UserRepo;
import com.demo.project.repo.UserRepository;



@Service
public class UService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private UserRepo userRepo;
    
    @Autowired
    private EmailService emailService;
   

    @Autowired
    private JavaMailSender javaMailSender;
    
    
    public UserReg registerUser(UserReg user) {
    	if (userRepository.findByEmail(user.getEmail()) != null) {
    		 throw new UserAlreadyRegisteredException("User already registered with this email");
        }
    	 String employeeId = generateEmployeeId();
    	 String password = generatePassword();
         user.setEmpid(employeeId);
         user.setPassword(password);
         
         // Send email with employee ID
         //sendEmployeeIdByEmail(user.getEmail(), employeeId);
         sendEmployeeIdAndPasswordByEmail(user.getEmail(), employeeId, password);
         return  userRepository.save(user);
         
    }
    
    private String generatePassword() {
        // Simple password generation logic
        return "pass" + new Random().nextInt(10000); // Replace with a more secure password generation logic
    }
    private void sendEmployeeIdAndPasswordByEmail(String email, String employeeId, String password) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your Employee ID and Password");
        message.setText("Your employee ID is: " + employeeId + "\nYour password is: " + password);

        javaMailSender.send(message);
    }
    private String generateEmployeeId() {
        String prefix = "EMP";
        long count = userRepository.count() + 1; // Simple count-based ID generation
        return prefix + String.format("%05d", count); 
    }
    
   /* private void sendEmployeeIdByEmail(String email, String employeeId) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your Employee ID");
        message.setText("Your employee ID is: " + employeeId);

        javaMailSender.send(message);
    }*/
 // Assume this method gets the verification code from the database or any data source
    public String getVerificationCodeForEmail(String email) {
    	UserReg user = userRepository.findByEmail(email);
        // Logic to retrieve the stored verification code for the given email
        return user.getVerificationCode(); // Example code
    }
//settings
    // Method to get user details by empid
    public UserReg getUserDetailsByEmpid(String empid) {
        return userRepository.findByEmpid(empid);
    }
 // Method to update user details
    public UserReg updateUserDetails(UserReg updatedUser) {
        UserReg existingUser = userRepository.findByEmpid(updatedUser.getEmpid());
        if (existingUser != null) {
            existingUser.setUsername(updatedUser.getUsername());
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setPassword(updatedUser.getPassword());
            existingUser.setMobile(updatedUser.getMobile());
            // Update other fields as needed

            return userRepository.save(existingUser);
        } else {
            throw new RuntimeException("User not found with empid: " + updatedUser.getEmpid());
        }
    }
    
    
    public UserReg loginUser(String username, String password) {
    	UserReg user = userRepository.findByEmpid(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
    
    public boolean resetPassword(String username, String newPassword) {
    	UserReg user = userRepository.findByEmpid(username);
        if (user != null) {
            user.setPassword(newPassword);
            userRepository.save(user);
            return true;
        }
        return false;
    }
    
    public User saveUserDetails(User user, String empid) {
        UserReg userReg = userRepository.findByEmpid(empid);
        if (userReg != null) {
           user.setUserReg(userReg);
            return userRepo.save(user);
        }
        return null;
    }
    public User createUser(User user, String empid) {
        UserReg userReg = userRepository.findByEmpid(empid);
        if (userReg != null) {
            user.setUserReg(userReg);
            return userRepo.save(user);
        } else {
            throw new IllegalArgumentException("Invalid empid: " + empid);
        }
    }
    
    public boolean authenticateUser(String empid, String password) {
        System.out.println("Authenticating user with empid: " + empid); // Debug statement
        UserReg userReg = userRepository.findByEmpid(empid);
        if (userReg != null) {
            System.out.println("User found with empid: " + empid); // Debug statement
            if (userReg.getPassword().equals(password)) {
                System.out.println("Password matched for empid: " + empid); // Debug statement
                return true;
            } else {
                System.out.println("Password did not match for empid: " + empid); // Debug statement
            }
        } else {
            System.out.println("User not found with empid: " + empid); // Debug statement
        }
        return false;
    }
    /*public void sendVerificationCode(UserReg userReg, String code) {
        String subject = "Your Verification Code";
        String message = "Your verification code is: " + code;

        emailService.sendSimpleEmail(userReg.getEmail(), subject, message);
    }

    public String generateVerificationCode() {
        Random random = new Random();
        int code = 100000 + random.nextInt(900000); // Generates a 6-digit code
        return String.valueOf(code);
    }*/
    
    public void sendVerificationCodeByEmail(String email, String verificationCode) {
    	System.out.println("hi");
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(email);

        msg.setSubject("Verification Code");
        msg.setText("Your verification code is: " + verificationCode);

        javaMailSender.send(msg);
    }
   public void sendVerificationCode(String email) {
        UserReg user = userRepository.findByEmail(email);
        if (user != null) {
        	System.out.println("Mail sending");
            String verificationCode = user.generateVerificationCode();
            user.setVerificationCode(verificationCode);
            userRepository.save(user); // Update the user with the verification code
            String subject = "Forgot Password Verification Code";
            String message = "Your verification code is: " + verificationCode;
            emailService.sendSimpleEmail(email, subject, message);
        } else {
            throw new IllegalArgumentException("Email not registered.");
        }
    }

   
    public boolean verifyVerificationCode(String email, String code) {
        UserReg user = userRepository.findByEmail(email);
        System.out.println("Verify "+code+user.getVerificationCode());
        if (user != null && code.equals(user.getVerificationCode())) {
            // Clear verification code after successful verification
            user.setVerificationCode(code);
            userRepository.save(user);
            return true;
        }
        return false;
    }
    public UserReg findByEmail(String email) {
        return userRepository.findByEmail(email); // Example method to fetch user by email
    }
    
    public UserReg getUserByEmpid(String empid) {
        return userRepository.findByEmpid(empid);
    }
    
    public List<User> getTasksByEmpid(String empid) {
        return userRepository.findByUserRegEmpid(empid);
    }


   
}
