
      function calculateTimeSpent() {
    const startTimeInput = document.getElementById('start-time').value;
    const endTimeInput = document.getElementById('end-time').value;
    const timeSpentInput = document.getElementById('time-spent');

    if (startTimeInput && endTimeInput) {
        const startTime = new Date(`1970-01-01T${startTimeInput}:00`);
        const endTime = new Date(`1970-01-01T${endTimeInput}:00`);
        let timeDiff = endTime - startTime;

        if (timeDiff < 0) {
            timeDiff += 24 * 60 * 60 * 1000;  // Handle overnight times
        }

        const hours = Math.floor(timeDiff / (1000 * 60 * 60));
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));

        timeSpentInput.value = `${hours}h ${minutes}m`;
    } else {
        timeSpentInput.value = '';
    }
}

function showTask() {
    document.getElementById('taskTab').classList.add('active');
    document.getElementById('listTab').classList.remove('active');
    document.getElementById('filterBtn').classList.remove('active');
    window.alert("Task clicked");

}

function navigateToList() {
    document.getElementById('taskTab').classList.remove('active');
    document.getElementById('listTab').classList.add('active');
    document.getElementById('filterBtn').classList.remove('active');
    window.alert("List clicked");

}
function showFilterOptions() {
    document.getElementById('taskTab').classList.remove('active');
    document.getElementById('listTab').classList.remove('active');
    document.getElementById('filterBtn').classList.add('active');
    window.alert("Filter clicked");
}

function navigateToLeave(){
    document.getElementById('leaveBtn').addEventListener('click', function() {
        window.location.href = 'leave.html';
    });
}


function showTasks() {

    console.log("Task clicked");
}

function showsLeaveOptions(){

        window.location.href = 'leave.html';
}

function navigateToLists() {
    console.log("List clicked");
}

function showsFilterOptions() {

    console.log("Filter clicked");
}
function toggleProfileCard() {
    const profileCard = document.querySelector('.profile-card');
    profileCard.style.display = profileCard.style.display === 'none' ? 'block' : 'none';

    document.addEventListener('click', function(event) {
        const profileCard = document.querySelector('.profile-card');
        const userLogo = document.querySelector('.user-logo');

        if (profileCard.style.display === 'block' && !profileCard.contains(event.target) && !userLogo.contains(event.target)) {
            profileCard.style.display = 'none';
        }
    });
}

function handleSidebarHover() {
    const liItems = document.querySelectorAll('.sidebar ul li');
    const wrapper = document.querySelector('.wrapper');

    liItems.forEach((liItem) => {
        liItem.addEventListener('mouseenter', () => {
            wrapper.classList.remove('hover_collapse');
        });
    });

    liItems.forEach((liItem) => {
        liItem.addEventListener('mouseleave', () => {
            wrapper.classList.add('hover_collapse');
        });
    });
}

// Function to handle hamburger click event
function handleHamburgerClick() {
    const hamburger = document.querySelector('.hamburger');
    const wrapper = document.querySelector('.wrapper');

    hamburger.addEventListener('click', () => {
        wrapper.classList.toggle('hover_collapse');
    });
}
function init() {
    // Ensure all sidebar links navigate correctly
    document.querySelectorAll('.sidebar ul li a').forEach(link => {
        link.addEventListener('click', function(event) {
            const targetHref = event.currentTarget.getAttribute('href');
            if (targetHref) {
                window.location.href = targetHref;
            }
        });
    });

    handleSidebarHover();
    handleHamburgerClick();
}

document.addEventListener('DOMContentLoaded', init);
/*
// Logout function
function logout() {
    window.location.href='login_user.html';
    alert('Logout successful!');
}

// Function to handle navigation to Task
function showTask() {
    window.location.href = 'register.html';
}

// Function to handle navigation to List
function navigateToList() {
    window.location.href = 'list.html';
}

// Function to handle navigation to Leave
function navigateToLeave() {
    window.location.href = 'leave.html';
}
function showTasks() {
    window.location.href = 'signin.html';
}

// Function to handle navigation to List
function navigateToLists() {
    window.location.href = 'list.html';
}
function showsLeaveOptions(){
    window.location.href = 'leave.html';
}*/
/*document.addEventListener('DOMContentLoaded', init);

function init() {
    handleSidebarHover();
    handleHamburgerClick();

    // Ensure all sidebar links navigate correctly
    document.querySelectorAll('.sidebar ul li a').forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default action
            const targetHref = event.currentTarget.getAttribute('href');
            if (targetHref) {
                window.location.href = targetHref;
            }
        });
    });
}

function handleSidebarHover() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.addEventListener('mouseenter', () => {
        sidebar.classList.add('hover');
    });
    sidebar.addEventListener('mouseleave', () => {
        sidebar.classList.remove('hover');
    });
}

function handleHamburgerClick() {
    const hamburger = document.querySelector('.hamburger');
    const sidebar = document.querySelector('.sidebar');
    hamburger.addEventListener('click', (event) => {
        event.stopPropagation(); // Prevent event bubbling
        sidebar.classList.toggle('active');
    });
}

// Close sidebar if clicked outside (for mobile)
document.addEventListener('click', (event) => {
    const sidebar = document.querySelector('.sidebar');
    const hamburger = document.querySelector('.hamburger');
    if (sidebar.classList.contains('active') && !sidebar.contains(event.target) && !hamburger.contains(event.target)) {
        sidebar.classList.remove('active');
    }
});
*/

//Function to handle sidebar mouseenter and mouseleave events
function handleSidebarHover() {
    const liItems = document.querySelectorAll('.sidebar ul li');
    const wrapper = document.querySelector('.wrapper');

    liItems.forEach((liItem) => {
        liItem.addEventListener('mouseenter', () => {
            wrapper.classList.remove('hover_collapse');
        });
    });

    liItems.forEach((liItem) => {
        liItem.addEventListener('mouseleave', () => {
            wrapper.classList.add('hover_collapse');
        });
    });
}

// Function to handle hamburger click event
function handleHamburgerClick() {
    const hamburger = document.querySelector('.hamburger');
    const wrapper = document.querySelector('.wrapper');

    hamburger.addEventListener('click', () => {
        wrapper.classList.toggle('hover_collapse');
    });
}
function init() {
    // Ensure all sidebar links navigate correctly
    document.querySelectorAll('.sidebar ul li a').forEach(link => {
        link.addEventListener('click', function(event) {
            const targetHref = event.currentTarget.getAttribute('href');
            if (targetHref) {
                window.location.href = targetHref;
            }
        });
    });

    handleSidebarHover();
    handleHamburgerClick();
}

document.addEventListener('DOMContentLoaded', init);
// Initialize event listeners
/*function init() {
    handleSidebarHover();
    handleHamburgerClick();
}*/



